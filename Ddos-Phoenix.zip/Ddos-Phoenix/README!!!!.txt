first, install python, heres the link: https://www.python.org/downloads/

then, open the setup.
when you did this open up powershell and type: cd "your folder where everything is saved".
then type: python phoenix.py

And now you are ready to use the tool, have fun!

If you have problems go up and publish the issue on my github